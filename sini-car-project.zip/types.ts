
export type UserRole = 
  | 'SUPER_ADMIN' 
  | 'CUSTOMER_OWNER' // Was ADMIN
  | 'CUSTOMER_STAFF'; // Was EMPLOYEE

export enum EmployeeRole {
  MANAGER = 'MANAGER', // Can view prices, order, manage
  BUYER = 'BUYER' // Can browse, add to cart (needs approval)
}

export enum CustomerType {
  SPARE_PARTS_SHOP = 'محل قطع غيار',
  RENTAL_COMPANY = 'شركة تأجير سيارات',
  SALES_REP = 'مندوب مبيعات',
  MAINTENANCE_CENTER = 'مركز صيانة',
  INSURANCE_COMPANY = 'شركة تأمين'
}

// --- Account Opening Request Types (New) ---

export type CustomerCategory =
  | 'SPARE_PARTS_SHOP'     // محل قطع غيار
  | 'INSURANCE_COMPANY'    // شركة تأمين
  | 'RENTAL_COMPANY'       // شركة تأجير سيارات
  | 'MAINTENANCE_CENTER'   // مركز صيانة
  | 'SALES_REP';           // مندوب مبيعات

// Updated Statuses
export type AccountRequestStatus = 
  | 'NEW'           // طلب جديد
  | 'UNDER_REVIEW'  // قيد المراجعة
  | 'APPROVED'      // تم الموافقة
  | 'REJECTED'      // مرفوض
  | 'ON_HOLD';      // مؤجل

// Admin Decision Enums
export type PriceLevel = 'LEVEL_1' | 'LEVEL_2' | 'LEVEL_3' | 'SPECIAL';

export type BusinessCustomerType =
  | 'PARTS_SHOP'        // محل قطع غيار
  | 'RENTAL_COMPANY'    // شركة تأجير سيارات
  | 'INSURANCE_COMPANY' // شركة تأمين
  | 'SALES_AGENT'       // مندوب مبيعات
  | 'FLEET_CUSTOMER'    // عميل أسطول سيارات
  | 'OTHER';

// Document Upload Types
export interface UploadedDocument {
  id: string;
  name: string;           // اسم الملف
  type: 'CR_CERTIFICATE' | 'VAT_CERTIFICATE' | 'NATIONAL_ID' | 'NATIONAL_ADDRESS' | 'OTHER';
  fileType: string;       // MIME type (pdf, image/*)
  fileSize: number;       // Size in bytes
  base64Data?: string;    // For demo/mock - in production would be a URL
  uploadedAt: string;
}

export interface AccountOpeningRequest {
  id: string;
  category: CustomerCategory;     // نوع النشاط
  status: AccountRequestStatus;   // NEW عند الإنشاء

  // بيانات عامة
  businessName?: string;          // اسم المنشأة أو الشركة (إجباري للشركات والمحلات)
  fullName?: string;              // الاسم الكامل (للمندوب)
  contactPerson?: string;         // شخص التواصل (للعرض فقط)
  phone: string;                  // رقم جوال للتواصل
  email?: string;

  // المستندات المرفقة
  documents?: UploadedDocument[];

  // للشركات والمحلات فقط:
  commercialRegNumber?: string;   // السجل التجاري
  vatNumber?: string;             // الرقم الضريبي
  nationalAddress?: string;       // العنوان الوطني
  branchesCount?: number;         // عدد الفروع

  // للمندوب:
  representativeRegion?: string;  // المنطقة/المدن التي يغطيها
  representativeClientsType?: string; // نوع العملاء الذين يخدمهم
  approximateClientsCount?: string;    // عدد العملاء التقريبي

  // معلومات عامة:
  country?: string;
  city?: string;
  hasImportedBefore?: boolean;
  previousDealingsNotes?: string;
  expectedMonthlyVolume?: string; // حجم التعامل التقريبي شهريًا أو سنويًا
  notes?: string;                 // ملاحظات إضافية

  // --- Admin Review Fields (New) ---
  reviewedBy?: string | null;             // اسم أو معرف الأدمن الذي راجع الطلب
  reviewedAt?: string | null;             // تاريخ المراجعة
  adminNotes?: string | null;             // ملاحظات داخلية للأدمن

  assignedPriceLevel?: PriceLevel | null; // مستوى التسعير المخصص للعميل
  assignedCustomerType?: BusinessCustomerType | null;

  // Search Permissions
  allowedSearchPoints?: number;           // (Legacy Field kept for compat)
  searchPointsInitial?: number | null;    // رصيد نقاط البحث الأولي
  searchPointsMonthly?: number | null;    // رصيد شهري يتم منحه (اختياري)
  searchDailyLimit?: number | null;       // حد أقصى يومي للبحث (اختياري)

  // Portal Access
  portalAccessStart?: string | null;      // تاريخ بداية صلاحية الدخول
  portalAccessEnd?: string | null;        // تاريخ نهاية الصلاحية (أو null = مفتوحة)

  // Staff Permissions
  canCreateStaff?: boolean;               // هل يُسمح له بإضافة موظفين؟
  maxStaffUsers?: number | null;          // أقصى عدد للموظفين المسموحين

  createdCustomerId?: string | null;      // في المستقبل: رقم العميل عند تحويل الطلب إلى حساب فعلي

  createdAt: string;
  updatedAt?: string;
  
  // Admin Badge Tracking
  isNew?: boolean;                        // For admin sidebar badge - true when unseen by admin
}

// ------------------------------------------

// --- Enhanced Customer & User Types for Admin Base ---

export type CustomerStatus =
  | 'ACTIVE'          // فعال
  | 'SUSPENDED'       // موقوف مؤقتًا
  | 'BLOCKED'         // محظور نهائيًا
  | 'PENDING'         // قيد التفعيل
  | 'INACTIVE';       // غير نشط (لا يستخدم النظام)

export type StaffStatus = 'ACTIVE' | 'SUSPENDED' | 'BLOCKED';

export interface Branch {
  id: string;
  name: string;
  city: string;
  address: string;
  phone?: string;
  mapUrl?: string;
}

export interface User {
  id: string;
  clientId: string; // The login ID (e.g., 100200) for Owners, or Phone for Staff
  name: string;
  email: string; // Kept for contact purposes only
  password?: string; // For Owners
  role: UserRole;
  
  // Relationship Fields
  parentId?: string; // If staff, links to the main account (Customer Owner ID)
  businessId?: string; // The Company/Entity ID (Shared between Owner and Staff)
  
  isActive?: boolean; // For banning users
  branchId?: string; // Which branch they belong to
  employeeRole?: EmployeeRole; // Specific permissions
  phone?: string;
  
  // Staff Specific
  activationCode?: string; // كود التفعيل للدخول

  // Search Credits Logic (New)
  searchLimit?: number;  // الحد الأقصى لنقاط البحث (0 = بحث مفتوح)
  searchUsed?: number;   // عدد عمليات البحث المستخدمة
  lastSearchDate?: string; // لتصفير العداد يومياً (YYYY-MM-DD)

  // Notifications & Badges (New)
  hasUnreadOrders?: boolean; // يظهر شارة حمراء على سجل الطلبات
  lastOrdersViewedAt?: string;
  hasUnreadQuotes?: boolean; // يظهر شارة حمراء على طلبات التسعير
  lastQuotesViewedAt?: string;

  // API Integration Preparation Fields (New)
  priceLevel?: string; // مستوى التسعير (A, B, C) - Legacy string, consider migrating to PriceLevel type
  isApproved?: boolean; // حالة الاعتماد من النظام الخارجي
  accountStatus?: string; // Active, Hold, Closed
  customerType?: string; // نوع العميل من النظام الخارجي

  // --- New Security & Status Fields ---
  status?: CustomerStatus; // New refined status
  lastLoginAt?: string | null;
  failedLoginAttempts?: number;
  riskyLoginFlag?: boolean;
  
  // --- Activity Tracking ---
  lastActiveAt?: string; // ISO timestamp of last heartbeat (for online status)
  
  // --- Guest Mode ---
  isGuest?: boolean; // Flag for guest users with restricted access
}

// --- Notifications System (New) ---
export type NotificationType =
  | 'ORDER_STATUS_CHANGED'
  | 'SEARCH_POINTS_ADDED'
  | 'QUOTE_PROCESSED'
  | 'GENERAL'
  | 'ACCOUNT_UPDATE'
  | 'IMPORT_UPDATE'
  | 'SYSTEM'; // System notifications (password reset, etc.)

export interface Notification {
  id: string;
  userId: string;
  type: NotificationType;
  title: string;
  message: string;
  createdAt: string;
  isRead: boolean;
  link?: string; // Optional link to redirect
}

export interface BusinessProfile {
  userId: string; // Links to the main User ID (Owner)
  companyName: string; // Usually the user name for main account
  phone: string;
  region: string;
  city: string;
  crNumber: string; // Commercial Registration
  taxNumber: string;
  nationalAddress: string;
  
  // Legacy Type
  customerType: CustomerType;
  
  deviceFingerprint: string;
  branches: Branch[];
  isApproved: boolean; // Approved by System #1

  // --- New Advanced Fields for Admin Base ---
  
  // Enhanced Type & Status
  businessCustomerType?: BusinessCustomerType; // Mapped from AccountRequest
  assignedPriceLevel?: PriceLevel;             // LEVEL_1 / LEVEL_2 ...
  status?: CustomerStatus;
  
  // Access Control
  portalAccessStart?: string | null;
  portalAccessEnd?: string | null;
  suspendedUntil?: string | null; // If suspended, until when?

  // Search Points Wallet
  searchPointsTotal?: number;          // مجموع النقاط الممنوحة
  searchPointsRemaining?: number;      // المتبقية (Alternative source of truth to User.searchLimit)

  // Staff Limits
  staffLimit?: number | null;          // الحد الأقصى لعدد الموظفين
  
  // Security
  lastLoginAt?: string | null;
  lastLoginIp?: string | null;
  failedLoginAttempts?: number;        // محاولات فاشلة منذ آخر نجاح
  riskyLoginFlag?: boolean;            // علم أن هذا العميل لديه سلوك دخول غريب
  
  // Internal Notes
  internalNotes?: string;

  // Customer Documents (from account opening request)
  documents?: UploadedDocument[];

  // Aggregated Stats (Computed on fly or cached)
  totalOrdersCount?: number;
  totalQuotesCount?: number;
  totalImportRequestsCount?: number;
  totalInvoicesCount?: number;         // عدد الطلبات التي تحولت إلى فاتورة
  totalSearchesCount?: number;         // إجمالي عمليات البحث
  missingRequestsCount?: number;       // عدد النواقص المسجلة منه
}

export interface Product {
  id: string;
  partNumber: string;         // رقم الصنف من عمود "رقم الصنف"
  name: string;               // اسم الصنف من عمود "اسم الصنف"
  
  // Legacy fields (kept for backward compatibility)
  brand?: string;             // Changan, MG - now optional
  price?: number;             // Legacy price field - optional
  stock?: number;             // Legacy stock - optional
  image?: string;
  
  // Marketing fields
  oldPrice?: number;
  isOnSale?: boolean;
  isNew?: boolean;
  description?: string;       // من " المواصفات"
  category?: string;
  
  // مستويات التسعير من نظام أونيكس برو:
  priceRetail?: number | null;        // من "سعر التجزئة"
  priceWholesale?: number | null;     // من "سعر الجملة"
  priceWholeWholesale?: number | null;// من "سعر جملة الجملة"
  priceEcommerce?: number | null;     // من "سعر المتجر الالكتروني"

  // الكميات:
  qtyStore103?: number | null;        // من "  كمية المخزن 103"
  qtyStore105?: number | null;        // من "  كمية المخزن 105"
  qtyTotal?: number | null;           // من "الإجمالي"

  // حقول إضافية (اختيارية):
  manufacturerPartNumber?: string | null; // من "رقم التصنيع"
  carName?: string | null;              // من " اسم السيارة"
  globalCategory?: string | null;       // من " التصنيف العالمي"
  modelYear?: string | null;            // من " سنة الصنع"
  quality?: string | null;              // من "الجودة"

  // مواقع الرفوف (اختيارية):
  rack103?: string | null;             // من "رف المخزن 103"
  rack105?: string | null;             // من "رف المخزن 105"

  // حقول نظامية:
  createdAt?: string;
  updatedAt?: string;
  
  // Search Indexing Fields (Optional)
  normalizedPart?: string;
  numericPartCore?: string;
  
  // قواعد رؤية الكمية للعملاء
  useVisibilityRuleForQty?: boolean;  // إذا true: تطبق قاعدة إخفاء الكمية على هذا المنتج
}

export interface CartItem extends Product {
  quantity: number;
}

export enum OrderStatus {
  PENDING = 'بانتظار الموافقة',
  APPROVED = 'تم الاعتماد',
  REJECTED = 'مرفوض',
  SHIPPED = 'تم الشحن',
  DELIVERED = 'تم التسليم',
  CANCELLED = 'تم الإلغاء' // Added Cancelled
}

// --- Internal Order Logic (Admin Only) ---
export type OrderInternalStatus =
  | 'NEW'                    // طلب جديد – لم يبدأ العمل عليه
  | 'SENT_TO_WAREHOUSE'      // تم إرسال الطلب للمستودع
  | 'WAITING_PAYMENT'        // في انتظار تأكيد تحويل العميل
  | 'PAYMENT_CONFIRMED'      // تم تأكيد التحويل / السداد
  | 'SALES_INVOICE_CREATED'  // تم إصدار فاتورة مبيعات
  | 'READY_FOR_SHIPMENT'     // جاهز للشحن/التسليم
  | 'COMPLETED_INTERNAL'     // مكتمل داخليًا
  | 'CANCELLED_INTERNAL';    // ملغى من قبل الإدارة داخليًا

export interface InternalStatusHistoryItem {
  status: OrderInternalStatus;
  changedAt: string;
  changedBy: string; // Admin Name
}

export interface Order {
  id: string;
  userId: string; // The actual user who made the order (Owner or Staff)
  businessId?: string; // Links order to the Business Profile
  createdByUserId?: string; // Same as userId, redundant but for clarity
  createdByName?: string; // Name of the person who clicked submit

  items: CartItem[];
  totalAmount: number;
  status: OrderStatus;
  date: string;
  branchId?: string; // Which branch ordered this
  
  // Cancellation Logic
  cancelledBy?: 'CUSTOMER' | 'ADMIN';
  cancelledAt?: string;

  // --- Admin Internal Workflow Fields ---
  internalStatus?: OrderInternalStatus;
  internalNotes?: string;
  internalStatusHistory?: InternalStatusHistoryItem[];
  
  // Badge tracking - for admin unread notification
  isNew?: boolean;
}

// --- Bulk Quote Logic (Enhanced for Admin Review) ---

export type QuoteRequestStatus =
  | 'NEW'               // جديد – لم يفتح من الأدمن
  | 'UNDER_REVIEW'      // قيد المراجعة في لوحة التحكم
  | 'PARTIALLY_APPROVED'// جزء من الأصناف معتمد وجزء ناقص
  | 'APPROVED'          // تم التسعير الكامل
  | 'QUOTED'            // Legacy compatible
  | 'PROCESSED'         // Legacy compatible
  | 'REJECTED';         // تم رفض الطلب بالكامل

export type PriceType = 'OEM' | 'AFTERMARKET' | 'BOTH';

// Updated Item Statuses: PENDING (New), APPROVED (Matched), MISSING (Not Found), REJECTED (Admin rejected)
export type QuoteItemApprovalStatus = 'PENDING' | 'APPROVED' | 'MISSING' | 'REJECTED';

// Legacy: MATCHED, NOT_FOUND, APPROVED, REJECTED kept for compatibility with old data
export type QuoteItemStatus = 'PENDING' | 'MATCHED' | 'NOT_FOUND' | 'APPROVED' | 'REJECTED' | 'MISSING';

export interface QuoteItem {
  partNumber: string;
  partName: string; // Name from excel
  requestedQty: number;
  
  // New Admin Review Fields
  approvalStatus?: QuoteItemApprovalStatus;
  adminNote?: string; // Reason for rejection or note
  rowIndex?: number; // Row index in original excel

  // Fields populated after matching
  matchedProductId?: string;
  matchedProductName?: string;
  matchedPrice?: number;
  isAvailable?: boolean;
  totalPrice?: number; // Calculated after approval
  
  // Legacy fields
  status?: QuoteItemStatus; 
  notes?: string; 
}

export interface QuoteRequest {
  id: string;
  userId: string;
  userName: string;
  companyName: string;
  date: string;
  
  status: QuoteRequestStatus; // NEW, UNDER_REVIEW, APPROVED, PARTIALLY_APPROVED...
  
  items: QuoteItem[];
  totalQuotedAmount?: number;
  priceType?: PriceType; // Selected price type
  processedDate?: string; // When admin finalized it

  // Admin Review Metadata
  adminReviewedBy?: string;
  adminReviewedAt?: string;
  adminGeneralNote?: string;
  
  approvedItemsCount?: number;
  missingItemsCount?: number;
  resultReady?: boolean; // Is ready for customer download
  
  // Admin Badge Tracking
  isNew?: boolean;                        // For admin sidebar badge - true when unseen by admin
}

// --- Missing Parts (Nawaqis) ---

export type MissingSource = 'QUOTE' | 'SEARCH';

// حالة التوفر عند البحث
export type MissingAvailabilityStatus = 'not_found' | 'out_of_stock';

// مصدر البحث
export type SearchSourceType = 'heroSearch' | 'catalogSearch' | 'quoteRequest';

export type MissingStatus =
  | 'NEW'            // نقص جديد لم يُعالَج بعد
  | 'UNDER_REVIEW'   // تحت الدراسة
  | 'ORDER_PLANNED'  // تم جدولة طلب استيراد
  | 'ORDERED'        // تم طلبه من المورد/الصين
  | 'ADDED_TO_STOCK' // تم إضافته كمنتج في النظام
  | 'IGNORED';       // تم تجاهله أو لا جدوى منه

export interface MissingProductRequest {
  id: string;
  userId: string; // Initiator
  source?: MissingSource; // 'QUOTE' or 'SEARCH'
  query: string;     // Part number or text searched
  createdAt: string;
  
  // Identity info
  userName?: string; 
  branchId?: string;
  
  // New fields for structured tracking (Optional for compatibility)
  partNumber?: string;
  normalizedPartNumber?: string;
  name?: string;
  brand?: string;
  carModel?: string;
  quantityRequested?: number;

  // If from QUOTE
  quoteRequestId?: string;
  quoteItemId?: string;

  // Aggregation & Stats
  totalRequestsCount?: number;      // How many times this item was requested
  uniqueCustomersCount?: number;    // How many unique customers
  customerIds?: string[];           // List of user IDs who requested this
  lastRequestedAt?: string;         // Most recent request date
  
  // Search Pipeline Fields (New)
  availabilityStatus?: MissingAvailabilityStatus;  // 'not_found' or 'out_of_stock'
  searchSource?: SearchSourceType;                  // 'heroSearch', 'catalogSearch', etc.
  searchCount?: number;                             // عدد مرات البحث عن نفس القطعة (للتجميع)
  lastSearchDate?: string;                          // آخر تاريخ بحث (YYYY-MM-DD)
  productId?: string;                               // معرف المنتج إذا كان موجودًا لكن نفذت الكمية

  // Management
  status?: MissingStatus;
  adminNotes?: string;
  importRequestId?: string;         // Link to future import request
  
  // Admin Badge Tracking
  isNew?: boolean;                        // For admin sidebar badge - true when unseen by admin
}

// --- Search Service Types ---

export type SearchResultType = 'NOT_FOUND' | 'FOUND_OUT_OF_STOCK' | 'FOUND_AVAILABLE';

export interface SearchResult {
  type: SearchResultType;
  product?: Product;           // المنتج إذا تم العثور عليه
  normalizedQuery?: string;    // الاستعلام بعد التطبيع
}

// --- New Features Interfaces ---

export interface SearchHistoryItem {
  id: string;
  userId: string;
  productId: string;
  partNumber: string;
  productName: string;
  viewedAt: string;      // ISO date
  priceSnapshot: number; // السعر وقت العرض
}

// --- Import From China Logic (Expanded) ---

export type ImportRequestStatus =
  | 'NEW'                      // طلب جديد – بانتظار مراجعة فريق صيني كار
  | 'UNDER_REVIEW'             // قيد المراجعة / التواصل مع العميل
  | 'WAITING_CUSTOMER_EXCEL'   // في انتظار ملف Excel من العميل
  | 'PRICING_IN_PROGRESS'      // يتم إعداد عرض السعر
  | 'PRICING_SENT'             // تم إرسال عرض السعر للعميل
  | 'WAITING_CUSTOMER_APPROVAL'// في انتظار موافقة العميل على عرض السعر
  | 'APPROVED_BY_CUSTOMER'     // العميل وافق على العرض – بدأ الاستيراد
  | 'IN_FACTORY'               // الطلب في المصنع/التجهيز
  | 'SHIPMENT_BOOKED'          // تم حجز الشحن
  | 'ON_THE_SEA'               // الشحنة في البحر
  | 'IN_PORT'                  // الشحنة في الميناء
  | 'CUSTOMS_CLEARED'          // تم التخليص الجمركي
  | 'ON_THE_WAY'               // في الطريق للمستودع / للعميل
  | 'DELIVERED'                // تم التسليم
  | 'CANCELLED'                // ملغي
  | 'IN_REVIEW'                // Legacy compatible
  | 'CONTACTED'                // Legacy compatible
  | 'CLOSED';                  // Legacy compatible

export interface ImportRequestTimelineEntry {
  status: ImportRequestStatus;
  note?: string | null;
  changedAt: string;     // ISO date
  changedBy: string;     // اسم أو معرف المستخدم (أدمن أو عميل)
  actorRole: 'ADMIN' | 'CUSTOMER';
}

export interface ImportRequest {
  id: string;
  customerId: string;         // المنشأة
  createdByUserId?: string;    // المستخدم الذي أنشأ الطلب
  businessName?: string;       // اسم المنشأة/الشركة
  createdAt: string;
  updatedAt?: string;

  // بيانات أساسية من نموذج العميل:
  branchesCount?: number;      // عدد الفروع
  targetCarBrands: string[];  // الشركات التي يريد توفير قطع غيارها
  brandPreferences?: string;  // الماركات المطلوبة (legacy alias)
  hasImportedBefore: boolean; // هل سبق له الاستيراد من الصين؟
  previousImportDetails?: string; // وصف مختصر إذا كانت الإجابة نعم

  serviceMode: 'FULL_SERVICE' | 'GOODS_ONLY';
  // FULL_SERVICE = نحن نشتري ونشحن ونخلص له (استيراد كامل)
  // GOODS_ONLY  = نجهز البضاعة فقط وهو يتولى الشحن والتخليص

  preferredPorts?: string;      // الميناء أو منفذ الوصول المفضل
  estimatedAnnualValue?: string; // قيمة أو كمية الاستيراد التقريبية سنوياً
  paymentPreference?: string;    // تفضيل طريقة الدفع

  notes?: string;              // ملاحظات إضافية من العميل
  status: ImportRequestStatus; // NEW عند الإنشاء

  // ملف Excel الخاص بقطع الاستيراد:
  customerExcelFileName?: string | null;
  customerExcelUploadedAt?: string | null;

  // بيانات التسعير:
  pricingPreparedBy?: string | null;
  pricingPreparedAt?: string | null;
  pricingFileNameForCustomer?: string | null; // اسم ملف التسعير (Excel/PDF) المخزّن
  pricingTotalAmount?: number | null;

  // موافقة العميل على عرض السعر:
  customerApprovedAt?: string | null;
  customerApprovalNote?: string | null;

  // خط الزمن:
  timeline?: ImportRequestTimelineEntry[];

  // ملاحظات إدارية داخلية:
  adminNotes?: string | null;
  assignedSalesRepId?: string | null; // الموظف المسؤول عن الاستيراد
  
  // Admin Badge Tracking
  isNew?: boolean;                        // For admin sidebar badge - true when unseen by admin
}

export interface Banner {
  id: string;
  title: string;
  subtitle: string;
  colorClass: string; // Tailwind class for gradient
  buttonText: string;
  imageUrl?: string;
  link?: string;
  isActive: boolean;
}

export interface WebhookConfig {
  id: string;
  name: string;
  url: string;
  events: string[];
  isActive: boolean;
  secret: string;
  lastTriggered?: string;
  status: 'Healthy' | 'Failing' | 'Inactive';
}

export interface ApiConfig {
  baseUrl: string;
  authToken: string;
  enableLiveSync: boolean;
  endpoints: {
    products: string;
    orders: string;
    customers: string;
  };
  webhookSecret?: string;
  // Advanced Integration Features
  environment: 'SANDBOX' | 'PRODUCTION';
  syncInterval: 'REALTIME' | '15MIN' | 'HOURLY' | 'DAILY';
  syncEntities: {
    products: boolean;
    inventory: boolean;
    prices: boolean;
    customers: boolean;
    orders: boolean;
  };
  webhooks: { url: string; events: string[]; active: boolean }[];
  fieldMapping: string; // JSON String for mapping
  debugMode: boolean;
  rateLimit: string; // Requests per minute
  // New Data Sharing Settings
  sharedData?: string[]; // Which data types to share via API
  syncDirection?: 'PULL' | 'PUSH' | 'BIDIRECTIONAL'; // Direction of sync
  timeout?: string; // Connection timeout in seconds
  retryOnFail?: boolean; // Retry failed requests
}

// Status Labels Configuration - Centralized status display names
export interface StatusLabelItem {
  label: string;
  color: string;
  bgColor: string;
  icon?: string;
  isDefault?: boolean;
  isSystem?: boolean;
  sortOrder?: number;
}

export interface StatusLabelsConfig {
  orderStatus: Record<string, StatusLabelItem>;
  orderInternalStatus: Record<string, StatusLabelItem>;
  accountRequestStatus: Record<string, StatusLabelItem>;
  quoteRequestStatus: Record<string, StatusLabelItem>;
  quoteItemStatus: Record<string, StatusLabelItem>;
  missingStatus: Record<string, StatusLabelItem>;
  importRequestStatus: Record<string, StatusLabelItem>;
  customerStatus: Record<string, StatusLabelItem>;
  staffStatus: Record<string, StatusLabelItem>;
}

export interface SiteSettings {
  siteName: string;
  description?: string;
  supportPhone: string;
  supportWhatsapp?: string;
  supportEmail: string;
  announcementBarColor: string;
  fontFamily: string; // 'Almarai', 'Cairo', 'Tajawal'
  apiConfig: ApiConfig;
  // New Fields
  maintenanceMode: boolean;
  primaryColor: string;
  logoUrl: string;
  // Text Manager
  uiTexts?: Record<string, string>;
  // News Ticker Settings
  tickerEnabled?: boolean;
  tickerText?: string;
  tickerSpeed?: number;
  tickerBgColor?: string;
  tickerTextColor?: string;
  // Status Labels Configuration
  statusLabels?: StatusLabelsConfig;
  
  // --- Product Visibility & Search Settings ---
  minVisibleQty?: number;           // أقل كمية لظهور المنتج للعملاء (default: 1)
  stockThreshold?: number;          // عتبة المخزون لتحديد "نفذت الكمية" (default: 0)
  
  // --- Why Sini Car Section ---
  whySiniCarTitle?: string;         // عنوان القسم
  whySiniCarFeatures?: FeatureCard[]; // بطاقات المميزات
  
  // --- Guest Mode Settings ---
  guestModeEnabled?: boolean;       // تفعيل/إيقاف الدخول كضيف
  
  // --- Guest Visibility Controls ---
  guestSettings?: GuestModeSettings;
}

// Guest Mode Visibility Settings - Controls what guests can see/access
export interface GuestModeSettings {
  // What sections are visible (but blurred) on home page
  showBusinessTypes?: boolean;      // قسم "من نخدم" (أنواع الأعمال)
  showMainServices?: boolean;       // قسم الخدمات الرئيسية
  showHowItWorks?: boolean;         // قسم "كيف تعمل المنظومة"
  showWhySiniCar?: boolean;         // قسم "لماذا صيني كار"
  showCart?: boolean;               // عربة التسوق الجانبية
  showMarketingCards?: boolean;     // بطاقات التسويق الجانبية
  
  // Blur settings
  blurIntensity?: 'light' | 'medium' | 'heavy';  // شدة التشويش
  showBlurOverlay?: boolean;        // إظهار overlay فوق المحتوى المشوش
  
  // Pages accessible to guests (empty = none except HOME)
  allowedPages?: string[];          // الصفحات المسموح الوصول إليها
  
  // Search settings
  allowSearch?: boolean;            // السماح بالبحث (نتائج مشوشة)
  showSearchResults?: boolean;      // إظهار نتائج البحث (مشوشة)
}

// Feature Card for "Why Sini Car" section
export interface FeatureCard {
  id: string;
  title: string;
  description: string;
  icon: 'box' | 'chart' | 'anchor' | 'headphones' | 'truck' | 'shield' | 'globe' | 'star' | 'clock' | 'award';
  iconColor: string; // Tailwind color class like 'text-cyan-400'
}

// --- Excel Import Column Presets ---

export interface ExcelColumnMapping {
  internalField: string;            // اسم الحقل الداخلي (partNumber, name, etc.)
  excelHeader: string;              // اسم العمود في ملف الإكسل
  isEnabled: boolean;               // هل هذا الحقل مفعل للاستيراد؟
  isRequired: boolean;              // هل هو حقل إجباري؟
  defaultValue?: string | number;   // قيمة افتراضية إذا كان العمود فارغًا
}

export interface ExcelColumnPreset {
  id: string;
  name: string;                     // اسم الإعداد (مثل "Onyx Export", "Supplier A")
  isDefault: boolean;               // هل هو الإعداد الافتراضي؟
  mappings: ExcelColumnMapping[];   // قائمة تعيينات الأعمدة
  createdAt: string;
  updatedAt?: string;
}

// الحقول الداخلية المتاحة للتعيين
export const INTERNAL_PRODUCT_FIELDS = [
  { key: 'partNumber', label: 'رقم الصنف', required: true },
  { key: 'name', label: 'اسم المنتج', required: true },
  { key: 'brand', label: 'الماركة', required: false },
  { key: 'qtyTotal', label: 'الكمية', required: true },
  { key: 'priceWholesale', label: 'سعر الجملة', required: false },
  { key: 'priceRetail', label: 'سعر التجزئة', required: false },
  { key: 'priceWholeWholesale', label: 'سعر جملة الجملة', required: false },
  { key: 'priceEcommerce', label: 'سعر المتجر الالكتروني', required: false },
  { key: 'qtyStore103', label: 'كمية المخزن 103', required: false },
  { key: 'qtyStore105', label: 'كمية المخزن 105', required: false },
  { key: 'rack103', label: 'رف المخزن 103', required: false },
  { key: 'rack105', label: 'رف المخزن 105', required: false },
  { key: 'carName', label: 'اسم السيارة', required: false },
  { key: 'description', label: 'المواصفات', required: false },
  { key: 'manufacturerPartNumber', label: 'رقم التصنيع', required: false },
  { key: 'globalCategory', label: 'التصنيف العالمي', required: false },
  { key: 'modelYear', label: 'سنة الصنع', required: false },
  { key: 'quality', label: 'الجودة', required: false },
] as const;

// --- Activity Log Types (New) ---

export type ActivityEventType =
  | 'LOGIN'              // دخول المستخدم للنظام
  | 'LOGOUT'             // تسجيل الخروج
  | 'FAILED_LOGIN'       // محاولة دخول فاشلة
  | 'PAGE_VIEW'          // فتح صفحة معينة
  | 'ORDER_CREATED'      // إنشاء/إرسال طلب من السلة
  | 'QUOTE_REQUEST'      // إنشاء طلب تسعير (رفع ملف أو إدخال يدوي)
  | 'QUOTE_REVIEWED'     // Admin reviewed quote
  | 'IMPORT_REQUEST'     // إنشاء طلب استيراد من الصين
  | 'ACCOUNT_REQUEST'    // تقديم طلب فتح حساب
  | 'ACCOUNT_REQUEST_REVIEWED' // مراجعة طلب فتح حساب (Admin)
  | 'SEARCH_PERFORMED'   // عملية بحث عن صنف
  | 'ORDER_CANCELLED'    // إلغاء طلب
  | 'ORDER_DELETED'      // حذف طلب
  | 'SEARCH_POINTS_ADDED' // إضافة نقاط بحث
  | 'ORDER_STATUS_CHANGED' // External status changed (Admin)
  | 'ORDER_INTERNAL_STATUS_CHANGED' // Internal status changed (Admin)
  | 'USER_SUSPENDED'     // إيقاف مستخدم
  | 'USER_REACTIVATED'   // إعادة تفعيل مستخدم
  | 'CUSTOMER_SUSPENDED' // إيقاف عميل
  | 'CUSTOMER_REACTIVATED' // إعادة تفعيل عميل
  | 'IMPORT_STATUS_CHANGED' // Import request status change
  | 'PASSWORD_CHANGED'   // تغيير كلمة المرور
  | 'PASSWORD_RESET'     // إعادة تعيين كلمة المرور (بواسطة الإدارة)
  | 'OTHER';             // عمليات أخرى عامة

export interface ActivityLogEntry {
  id: string;            // رقم فريد للنشاط
  userId: string;        // المستخدم الذي قام بالنشاط
  userName?: string;     // اسم المستخدم
  role?: UserRole;       // دور المستخدم
  eventType: ActivityEventType;

  // تفاصيل إضافية
  description?: string;  // نص وصفي للنشاط بالعربي
  page?: string;         // اسم الصفحة أو المسار
  metadata?: Record<string, any>; // كائن اختياري لوضع تفاصيل إضافية

  createdAt: string;     // التاريخ والوقت الكامل للنشاط
}

// --- Admin Users Management Types ---

export interface AdminUser {
  id: string;
  fullName: string;       // الاسم الكامل
  username: string;       // اسم المستخدم
  phone: string;          // رقم الجوال
  email?: string;         // البريد الإلكتروني (اختياري)
  password?: string;      // كلمة المرور (مشفرة في الإنتاج)
  roleId: string;         // معرف الدور المرتبط
  isActive: boolean;      // نشط / موقوف
  lastLoginAt?: string;   // آخر تسجيل دخول
  createdAt: string;      // تاريخ الإنشاء
  createdBy?: string;     // أنشئ بواسطة
}

// --- Roles & Permissions Types ---

export type PermissionAction =
  | 'view'
  | 'create'
  | 'edit'
  | 'delete'
  | 'approve'
  | 'reject'
  | 'export'
  | 'import'
  | 'configure'
  | 'manage_status'
  | 'manage_users'
  | 'manage_roles'
  | 'run_backup'
  | 'manage_api'
  | 'other';

export type PermissionResource =
  | 'dashboard'
  | 'products'
  | 'customers'
  | 'customer_requests'
  | 'account_requests'
  | 'quotes'
  | 'orders'
  | 'imports'
  | 'missing'
  | 'crm'
  | 'activity_log'
  | 'notifications'
  | 'settings_general'
  | 'settings_status_labels'
  | 'settings_api'
  | 'settings_backup'
  | 'settings_security'
  | 'users'
  | 'roles'
  | 'export_center'
  | 'content_management'
  | 'other';

export interface Permission {
  resource: PermissionResource;
  actions: PermissionAction[];
}

export interface Role {
  id: string;
  name: string;           // اسم الدور بالعربية
  description?: string;   // وصف الدور
  permissions: Permission[];
  isSystem?: boolean;     // أدوار النظام لا يمكن حذفها
  createdAt?: string;
}

// تسميات الموارد بالعربية
export const PERMISSION_RESOURCE_LABELS: Record<PermissionResource, string> = {
  dashboard: 'لوحة التحكم',
  products: 'المنتجات',
  customers: 'العملاء',
  customer_requests: 'طلبات العملاء',
  account_requests: 'طلبات فتح الحسابات',
  quotes: 'عروض الأسعار',
  orders: 'الطلبات',
  imports: 'طلبات الاستيراد',
  missing: 'النواقص',
  crm: 'قاعدة العملاء',
  activity_log: 'سجل النشاط',
  notifications: 'الإشعارات',
  settings_general: 'الإعدادات العامة',
  settings_status_labels: 'مسميات الحالات',
  settings_api: 'إعدادات API',
  settings_backup: 'النسخ الاحتياطي',
  settings_security: 'إعدادات الأمان',
  users: 'المستخدمون',
  roles: 'الأدوار والصلاحيات',
  export_center: 'مركز التصدير',
  content_management: 'إدارة المحتوى',
  other: 'أخرى'
};

// تسميات الإجراءات بالعربية
export const PERMISSION_ACTION_LABELS: Record<PermissionAction, string> = {
  view: 'عرض',
  create: 'إضافة',
  edit: 'تعديل',
  delete: 'حذف',
  approve: 'موافقة',
  reject: 'رفض',
  export: 'تصدير',
  import: 'استيراد',
  configure: 'إعدادات',
  manage_status: 'إدارة الحالات',
  manage_users: 'إدارة المستخدمين',
  manage_roles: 'إدارة الأدوار',
  run_backup: 'تشغيل النسخ الاحتياطي',
  manage_api: 'إدارة API',
  other: 'أخرى'
};

// الإجراءات المتاحة لكل مورد
export const RESOURCE_AVAILABLE_ACTIONS: Record<PermissionResource, PermissionAction[]> = {
  dashboard: ['view'],
  products: ['view', 'create', 'edit', 'delete', 'export', 'import'],
  customers: ['view', 'create', 'edit', 'delete', 'export', 'manage_status'],
  customer_requests: ['view', 'edit', 'approve', 'reject', 'export'],
  account_requests: ['view', 'approve', 'reject', 'export'],
  quotes: ['view', 'create', 'edit', 'delete', 'approve', 'reject', 'export'],
  orders: ['view', 'create', 'edit', 'delete', 'approve', 'reject', 'export', 'manage_status'],
  imports: ['view', 'create', 'edit', 'delete', 'approve', 'reject', 'export', 'manage_status'],
  missing: ['view', 'create', 'edit', 'delete', 'export', 'manage_status'],
  crm: ['view', 'create', 'edit', 'delete', 'export'],
  activity_log: ['view', 'export'],
  notifications: ['view', 'create', 'delete'],
  settings_general: ['view', 'configure'],
  settings_status_labels: ['view', 'create', 'edit', 'delete'],
  settings_api: ['view', 'configure', 'manage_api'],
  settings_backup: ['view', 'run_backup'],
  settings_security: ['view', 'configure'],
  users: ['view', 'create', 'edit', 'delete', 'manage_users'],
  roles: ['view', 'create', 'edit', 'delete', 'manage_roles'],
  export_center: ['view', 'export'],
  content_management: ['view', 'create', 'edit', 'delete'],
  other: ['view', 'other']
};

// --- Global Status Labels Management Types ---

export type StatusDomain = keyof StatusLabelsConfig;

export const STATUS_DOMAIN_LABELS: Record<StatusDomain, string> = {
  orderStatus: 'حالات الطلبات',
  orderInternalStatus: 'الحالات الداخلية للطلبات',
  accountRequestStatus: 'حالات طلبات فتح الحساب',
  quoteRequestStatus: 'حالات طلبات عروض الأسعار',
  quoteItemStatus: 'حالات عناصر عرض السعر',
  missingStatus: 'حالات النواقص',
  importRequestStatus: 'حالات طلبات الاستيراد',
  customerStatus: 'حالات العملاء',
  staffStatus: 'حالات الموظفين'
};

// --- Notification Management System Types ---

export type NotificationChannel = 'toast' | 'popup' | 'banner' | 'bell' | 'email' | 'sms';

export type NotificationCategory =
  | 'order'
  | 'quote'
  | 'account'
  | 'import'
  | 'search'
  | 'system'
  | 'marketing'
  | 'alert';

export interface NotificationStyle {
  backgroundColor?: string;
  textColor?: string;
  borderColor?: string;
  iconColor?: string;
  icon?: string;
  animation?: 'slide' | 'fade' | 'bounce' | 'none';
  position?: 'top-right' | 'top-left' | 'bottom-right' | 'bottom-left' | 'top-center' | 'bottom-center';
  duration?: number;
  showProgress?: boolean;
  showCloseButton?: boolean;
}

export interface NotificationTemplate {
  id: string;
  key: string;
  name: string;
  category: NotificationCategory;
  channel: NotificationChannel;
  isActive: boolean;
  
  // Localized content
  content: {
    ar: { title: string; message: string };
    en: { title: string; message: string };
    hi: { title: string; message: string };
    zh: { title: string; message: string };
  };
  
  // Styling
  style: NotificationStyle;
  
  // Metadata
  isSystem?: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export interface NotificationSettings {
  globalEnabled: boolean;
  defaultDuration: number;
  defaultPosition: NotificationStyle['position'];
  maxVisible: number;
  soundEnabled: boolean;
  templates: NotificationTemplate[];
}

// --- PDF/Print Template Designer Types ---

export type DocumentTemplateType = 
  | 'invoice'
  | 'order'
  | 'quote'
  | 'receipt'
  | 'delivery_note'
  | 'packing_list'
  | 'price_list'
  | 'report';

export type PageSize = 'A4' | 'A5' | 'Letter' | 'Legal';
export type PageOrientation = 'portrait' | 'landscape';

export interface TemplateMargins {
  top: number;
  right: number;
  bottom: number;
  left: number;
}

export interface TemplateHeaderFooter {
  enabled: boolean;
  height: number;
  showLogo: boolean;
  logoPosition?: 'left' | 'center' | 'right';
  logoSize?: number;
  showCompanyName: boolean;
  showDate: boolean;
  showPageNumber: boolean;
  customText?: string;
  backgroundColor?: string;
  textColor?: string;
  borderBottom?: boolean;
  borderTop?: boolean;
}

export interface TemplateField {
  id: string;
  key: string;
  label: string;
  labelAr: string;
  type: 'text' | 'number' | 'date' | 'currency' | 'image' | 'qrcode' | 'barcode';
  enabled: boolean;
  required: boolean;
  width?: number;
  alignment?: 'left' | 'center' | 'right';
  fontSize?: number;
  fontWeight?: 'normal' | 'bold';
  order: number;
}

export interface TemplateTableColumn {
  id: string;
  key: string;
  header: string;
  headerAr: string;
  width: number;
  alignment: 'left' | 'center' | 'right';
  enabled: boolean;
  order: number;
}

export interface TemplateSection {
  id: string;
  name: string;
  type: 'header' | 'info' | 'table' | 'summary' | 'footer' | 'custom';
  enabled: boolean;
  order: number;
  fields?: TemplateField[];
  tableColumns?: TemplateTableColumn[];
  customContent?: string;
  backgroundColor?: string;
  padding?: number;
  borderRadius?: number;
}

export interface DocumentTemplate {
  id: string;
  name: string;
  nameAr: string;
  type: DocumentTemplateType;
  isDefault: boolean;
  isActive: boolean;
  
  // Page Settings
  pageSize: PageSize;
  orientation: PageOrientation;
  margins: TemplateMargins;
  
  // Branding
  logoUrl?: string;
  primaryColor: string;
  secondaryColor: string;
  fontFamily: string;
  fontSize: number;
  
  // Header & Footer
  header: TemplateHeaderFooter;
  footer: TemplateHeaderFooter;
  
  // Sections
  sections: TemplateSection[];
  
  // Watermark
  watermark?: {
    enabled: boolean;
    text?: string;
    imageUrl?: string;
    opacity: number;
    position: 'center' | 'diagonal';
  };
  
  // Localization
  defaultLanguage: 'ar' | 'en';
  showBilingual: boolean;
  
  // Metadata
  createdAt?: string;
  updatedAt?: string;
}

export interface PrintSettings {
  templates: DocumentTemplate[];
  companyInfo: {
    name: string;
    nameEn?: string;
    address: string;
    phone: string;
    email: string;
    website?: string;
    taxNumber?: string;
    crNumber?: string;
    logoUrl?: string;
  };
  defaultTemplate: Record<DocumentTemplateType, string>;
}

// --- Sidebar Preferences Types ---

export interface SidebarPreferences {
  collapsed: boolean;
  width: number;
  mobileAutoClose: boolean;
}
